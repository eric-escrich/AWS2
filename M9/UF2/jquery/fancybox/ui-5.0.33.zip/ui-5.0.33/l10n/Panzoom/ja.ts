export const ja = {
  PANUP: "上に移動",
  PANDOWN: "下に移動",
  PANLEFT: "左に移動",
  PANRIGHT: "右に動く",

  ZOOMIN: "ズームイン",
  ZOOMOUT: "ズームアウトする",

  TOGGLEZOOM: "ズーム レベルの切り替え",
  TOGGLE1TO1: "ズーム レベルの切り替え",
  ITERATEZOOM: "ズーム レベルの切り替え",

  ROTATECCW: "反時計回りに回転",
  ROTATECW: "時計回りに回転します",

  FLIPX: "左右反転",
  FLIPY: "上下反転",

  FITX: "水平に合わせる",
  FITY: "縦に合わせる",

  RESET: "リセット",

  TOGGLEFS: "フルスクリーン切り替え",
};
