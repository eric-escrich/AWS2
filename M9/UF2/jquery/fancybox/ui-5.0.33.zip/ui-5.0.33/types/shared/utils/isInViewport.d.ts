export declare const isInViewport: (element: HTMLElement) => number;
