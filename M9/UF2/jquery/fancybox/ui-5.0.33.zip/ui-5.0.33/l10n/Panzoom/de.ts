export const de = {
  PANUP: "Aufwärts bewegen",
  PANDOWN: "Nach unten bewegen",
  PANLEFT: "Nach links bewegen",
  PANRIGHT: "Nach rechts bewegen",

  ZOOMIN: "Vergrößern",
  ZOOMOUT: "Verkleinern",

  TOGGLEZOOM: "Zoomstufe umschalten",
  TOGGLE1TO1: "Zoomstufe umschalten",
  ITERATEZOOM: "Zoomstufe umschalten",

  ROTATECCW: "Gegen den Uhrzeigersinn drehen",
  ROTATECW: "Im Uhrzeigersinn drehen",

  FLIPX: "Horizontal spiegeln",
  FLIPY: "Vertikal spiegeln",

  FITX: "Horizontal einpassen",
  FITY: "Vertikal anpassen",

  RESET: "Zurücksetzen",

  TOGGLEFS: "Vollbild umschalten",
};
