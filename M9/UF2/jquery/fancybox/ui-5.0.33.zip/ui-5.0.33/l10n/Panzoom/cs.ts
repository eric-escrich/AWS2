export const cs = {
  PANUP: "Posunout nahoru",
  PANDOWN: "Posunout dolů",
  PANLEFT: "Posunout vlevo",
  PANRIGHT: "Posunout vpravo",

  ZOOMIN: "Přiblížit",
  ZOOMOUT: "Oddálit",

  TOGGLEZOOM: "Přepnout úroveň přiblížení",
  TOGGLE1TO1: "Přepnout úroveň přiblížení",
  ITERATEZOOM: "Přepnout úroveň přiblížení",

  ROTATECCW: "Otočit směrem vlevo",
  ROTATECW: "Otočit směrem vpravo",

  FLIPX: "Převrátit vodorovně",
  FLIPY: "Převrátit svisle",

  FITX: "Přizpůsobit na šířku",
  FITY: "Přizpůsobit na výšku",

  RESET: "Resetovat",

  TOGGLEFS: "Režim celé obrazovky",
};
