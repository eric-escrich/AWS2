export const de = {
  NEXT: "Nächste Folie",
  PREV: "Vorherige Folie",
  GOTO: "Zur #%d Folie gehen",
};
