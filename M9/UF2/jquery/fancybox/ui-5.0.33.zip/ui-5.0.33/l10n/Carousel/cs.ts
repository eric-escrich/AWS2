export const cs = {
  NEXT: "Další",
  PREV: "Předchozí",
  GOTO: "Přejít na %d. snímek",
};
