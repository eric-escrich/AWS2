export const en = {
  NEXT: "Next slide",
  PREV: "Previous slide",
  GOTO: "Go to slide #%d",
};
