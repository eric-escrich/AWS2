export const sk = {
  NEXT: "Ďalší",
  PREV: "Predchádzajúci",
  GOTO: "Prejsť na %d. snímok",
};
