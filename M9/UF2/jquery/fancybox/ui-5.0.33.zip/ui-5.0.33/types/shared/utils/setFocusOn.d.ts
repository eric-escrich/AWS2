export declare const FOCUSABLE_ELEMENTS: string;
export declare const setFocusOn: (node: HTMLElement) => void;
