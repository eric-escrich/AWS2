export const sk = {
  PANUP: "Posunúť hore",
  PANDOWN: "Posunúť dole",
  PANLEFT: "Posunúť vľavo",
  PANRIGHT: "Posunúť vpravo",

  ZOOMIN: "Priblížiť",
  ZOOMOUT: "Oddialiť",

  TOGGLEZOOM: "Prepnúť úroveň priblíženia",
  TOGGLE1TO1: "Prepnúť úroveň priblíženia",
  ITERATEZOOM: "Prepnúť úroveň priblíženia",

  ROTATECCW: "Otočiť doľava",
  ROTATECW: "Otočiť doprava",

  FLIPX: "Prevrátiť vodorovne",
  FLIPY: "Prevrátiť zvisle",

  FITX: "Prispôsobiť na šírku",
  FITY: "Prispôsobiť na výšku",

  RESET: "Resetovať",

  TOGGLEFS: "Režim celej obrazovky",
};
