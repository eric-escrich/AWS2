export declare const spinner: string;
