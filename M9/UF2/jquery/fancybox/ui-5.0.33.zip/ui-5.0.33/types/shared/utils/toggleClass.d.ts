export declare const toggleClass: (el: HTMLElement | null, classes?: string, condition?: boolean) => void;
