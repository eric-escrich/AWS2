export const es = {
  NEXT: "Siguiente diapositiva",
  PREV: "Diapositiva anterior",
  GOTO: "Ir a la diapositiva #%d",
};
