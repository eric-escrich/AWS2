export const pl = {
  NEXT: "Następny slajd",
  PREV: "Poprzedni slajd",
  GOTO: "Idź do slajdu nr #%d",
};
