export const lv = {
  NEXT: "Nākošais slaids",
  PREV: "Iepriekšējais slaids",
  GOTO: "Doties uz #%d slaidu",
};
