export const it = {
  NEXT: "Diapositiva successiva",
  PREV: "Diapositiva precedente",
  GOTO: "Vai alla diapositiva #%d",
};
