export const lv = {
  PANUP: "Bīdīt uz augšu",
  PANDOWN: "Bīdīt uz leju",
  PANLEFT: "Bīdīt pa kreisi",
  PANRIGHT: "Bīdīt pa labi",

  ZOOMIN: "Pietuvināt",
  ZOOMOUT: "Attālināt",

  TOGGLEZOOM: "Pārslēgt tālummaiņas līmeni",
  TOGGLE1TO1: "Pārslēgt tālummaiņas līmeni",
  ITERATEZOOM: "Pārslēgt tālummaiņas līmeni",

  ROTATECCW: "Pagrieziet pretēji pulksteņrādītāja virzienam",
  ROTATECW: "Pagrieziet pulksteņrādītāja virzienā",

  FLIPX: "Apgriezt horizontāli",
  FLIPY: "Apgriezt vertikāli",

  FITX: "Ietilpināt horizontāli",
  FITY: "Ietilpināt vertikāli",

  RESET: "Atiestatīt",

  TOGGLEFS: "Pārslēgt pilnekrāna režīmu",
};
