export const es = {
  PANUP: "Mover hacia arriba",
  PANDOWN: "Mover hacia abajo",
  PANLEFT: "Mover hacia la izquierda",
  PANRIGHT: "Mover hacia la derecha",

  ZOOMIN: "Mover a la derecha",
  ZOOMOUT: "Disminuir el zoom",

  TOGGLEZOOM: "Alternar nivel de zoom",
  TOGGLE1TO1: "Alternar nivel de zoom",
  ITERATEZOOM: "Alternar nivel de zoom",

  ROTATECCW: "Girar en sentido antihorario",
  ROTATECW: "Rotar las agujas del reloj",

  FLIPX: "Voltear horizontalmente",
  FLIPY: "Voltear verticalmente",

  FITX: "Ajustar horizontalmente",
  FITY: "Ajustar verticalmente",

  RESET: "Reiniciar",

  TOGGLEFS: "Alternar pantalla completa",
};
