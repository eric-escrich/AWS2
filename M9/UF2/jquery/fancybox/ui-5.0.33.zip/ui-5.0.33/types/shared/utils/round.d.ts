/**
 * Round half up; to be more specific and to ensure things like 1.005 round correctly
 */
export declare const round: (value: number | string, precision?: number) => number;
