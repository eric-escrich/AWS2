/**
 * Wrapper for "Fullscreen API"
 */
export declare const getFsAPI: () => any;
